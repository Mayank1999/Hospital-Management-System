
-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `sr_no` int(254) NOT NULL,
  `name` varchar(200) NOT NULL,
  `patrel` varchar(200) NOT NULL,
  `rating` varchar(200) NOT NULL,
  `issues` varchar(300) NOT NULL,
  `suggestions` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`sr_no`, `name`, `patrel`, `rating`, `issues`, `suggestions`) VALUES
(1, 'Mohanbhai Shah', 'Yourself', '4', 'Not proper service of \r\ndoctors', 'No');
