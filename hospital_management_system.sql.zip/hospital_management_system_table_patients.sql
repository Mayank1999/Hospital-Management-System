
-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `sr_no` int(254) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Gender` varchar(200) NOT NULL,
  `DOB` varchar(200) NOT NULL,
  `Mobile` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`sr_no`, `Name`, `Username`, `Password`, `Gender`, `DOB`, `Mobile`, `Email`, `Address`) VALUES
(1, 'Mohanbhai Shah', 'Mohan2654', 'Mohan@2654', 'male', '1973-06-13', '7654987622', 'mohanshah99@gmail.com', 'F-205, Shalini Apartment, Opposite \r\nMotera Stadium, Motera, Ahmedabad');
