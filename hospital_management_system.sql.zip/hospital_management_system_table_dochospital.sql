
-- --------------------------------------------------------

--
-- Table structure for table `dochospital`
--

CREATE TABLE `dochospital` (
  `sr_no` int(254) NOT NULL,
  `name` varchar(200) NOT NULL,
  `docid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dochospital`
--

INSERT INTO `dochospital` (`sr_no`, `name`, `docid`) VALUES
(1, 'Chirag Desai', 'EYE101');
