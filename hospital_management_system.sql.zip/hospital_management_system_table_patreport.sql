
-- --------------------------------------------------------

--
-- Table structure for table `patreport`
--

CREATE TABLE `patreport` (
  `sr_no` int(254) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `docname` varchar(200) NOT NULL,
  `healthissue` varchar(500) NOT NULL,
  `medication` varchar(200) NOT NULL,
  `dateofapp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patreport`
--

INSERT INTO `patreport` (`sr_no`, `Username`, `docname`, `healthissue`, `medication`, `dateofapp`) VALUES
(1, 'Mohan2654', 'Chirag Desai', 'Glaucoma', 'Travatan Eye Drops', '2019-10-24'),
(2, 'Mohan2654', 'Chirag Desai', 'Conjuctivitis', 'Ciprofloxacin Eye Drops', '2019-11-20');
